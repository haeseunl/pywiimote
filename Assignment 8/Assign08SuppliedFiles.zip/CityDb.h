// FILE: CityDb.h
// CLASS PROVIDED: city_db
//     (a custom class for a collection of city records)

#ifndef CITY_DB_H
#define CITY_DB_H

// include relevant header files here

namespace cs3358Spring2007Assign08
{
   class city_db
   {
   public:

   private:
   };

   // NONMEMBER functions for the city_db class

}

#endif
