// FILE: CityDb.cpp
// CLASS IMPLEMENTED: city_db (see CityDb.h for documentation)
// INVARIANT of the ADT:
// ????
//
// Documentation for functions client don't have to know:
//
// void bst_remove_max(binary_tree_node<city_record>*& root_ptr,
//                     city_record& removed)
//   Precondition: root_ptr is a root pointer of a non-empty
//   binary search tree.
//   Postcondition: The city record with the largest city code
//   in the binary search tree has been removed, and root_ptr
//   now points to the root of the new (smaller) binary search
//   tree. The reference parameter, removed, has been set to a
//   copy of the removed city record.
//
// void bst_remove(binary_tree_node<city_record>*& root_ptr,
//                 const city_record& target)
//   Precondition: root_ptr is a root pointer of a binary search
//   tree (or may be 0 for the empty tree)
//   Postcondition: If target was in the tree, then one copy of
//   target has been removed, and toot_ptr now points to the
//   root of the new (smaller) binary search tree. Otherwise,
//   if target was not in the tree, then the tree is unchanged.
//
// ...
//

// include relevant header files here

namespace cs3358Spring2007Assign08
{


}
